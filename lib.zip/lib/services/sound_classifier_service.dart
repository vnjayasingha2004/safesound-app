import 'dart:async';
import 'dart:collection';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:record/record.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'prediction_smoother.dart';

class SoundClassificationResult {
  final String label;
  final String rawLabel;
  final String scene;
  final double confidence;
  final double rawConfidence;
  final bool isStable;
  final List<MapEntry<String, double>> topPredictions;
  final int inferenceTimeMs;
  final double currentDb;
  final double smoothedDb;

  const SoundClassificationResult({
    required this.label,
    required this.rawLabel,
    required this.scene,
    required this.confidence,
    required this.rawConfidence,
    required this.isStable,
    required this.topPredictions,
    required this.inferenceTimeMs,
    required this.currentDb,
    required this.smoothedDb,
  });

  static const empty = SoundClassificationResult(
    label: 'Waiting for audio',
    rawLabel: '',
    scene: 'Unknown',
    confidence: 0.0,
    rawConfidence: 0.0,
    isStable: false,
    topPredictions: [],
    inferenceTimeMs: 0,
    currentDb: 0.0,
    smoothedDb: 0.0,
  );
}

class SoundClassifierService {
  static const String _modelPath = 'assets/models/yamnet.tflite';
  static const String _labelPath = 'assets/labels/yamnet_label_list.txt';

  static const int _sampleRate = 16000;
  static const int _numChannels = 1;
  static const int _targetInputSamples = 15600;
  static const int _inferenceIntervalMs = 1200;
  static const int _uiEmitIntervalMs = 100;

  final AudioRecorder _recorder = AudioRecorder();
  final Queue<double> _waveformBuffer = Queue<double>();
  final Queue<double> _dbWindow = Queue<double>();

  final PredictionSmoother _smoother = PredictionSmoother(
    windowSize: 8,
    minStableFrames: 4,
    minAverageConfidence: 0.22,
    minDominanceGap: 0.06,
    holdFramesAfterLoss: 3,
    fallbackLabel: 'Ambient / Unknown',
  );

  Interpreter? _interpreter;
  StreamSubscription<Uint8List>? _audioSubscription;
  StreamController<SoundClassificationResult>? _controller;

  List<String> _labels = const [];
  bool _isInitialized = false;

  DateTime? _lastInferenceAt;
  DateTime? _lastUiEmitAt;

  String _lastLabel = 'Waiting for audio';
  String _lastRawLabel = '';
  String _lastScene = 'Unknown';
  double _lastConfidence = 0.0;
  double _lastRawConfidence = 0.0;
  bool _lastIsStable = false;
  List<MapEntry<String, double>> _lastTopPredictions = const [];
  int _lastInferenceTimeMs = 0;
  double _lastSmoothedDb = 0.0;

  Future<void> initialize() async {
    if (_isInitialized) return;

    final labelsText = await rootBundle.loadString(_labelPath);
    _labels = labelsText
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList();

    final options = InterpreterOptions()..threads = 2;
    _interpreter = await Interpreter.fromAsset(_modelPath, options: options);
    _interpreter!.allocateTensors();

    _isInitialized = true;
  }

  Future<Stream<SoundClassificationResult>> startListening() async {
    if (!_isInitialized) {
      throw StateError(
        'SoundClassifierService.initialize() must be called first.',
      );
    }

    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) {
      throw StateError('Microphone permission not granted.');
    }

    await stop();

    _controller = StreamController<SoundClassificationResult>.broadcast();
    _waveformBuffer.clear();
    _dbWindow.clear();
    _lastInferenceAt = null;
    _lastUiEmitAt = null;
    _lastSmoothedDb = 0.0;
    _resetLastAiState();
    _smoother.reset();

    final stream = await _recorder.startStream(
      const RecordConfig(
        encoder: AudioEncoder.pcm16bits,
        sampleRate: _sampleRate,
        numChannels: _numChannels,
        autoGain: true,
        echoCancel: false,
        noiseSuppress: false,
        streamBufferSize: 2048,
      ),
    );

    _audioSubscription = stream.listen(
      (bytes) {
        unawaited(_handleAudioChunk(bytes));
      },
      onError: (error, stackTrace) {
        _controller?.addError(error, stackTrace);
      },
    );

    return _controller!.stream;
  }

  void _resetLastAiState() {
    _lastLabel = 'Waiting for audio';
    _lastRawLabel = '';
    _lastScene = 'Unknown';
    _lastConfidence = 0.0;
    _lastRawConfidence = 0.0;
    _lastIsStable = false;
    _lastTopPredictions = const [];
    _lastInferenceTimeMs = 0;
  }

  List<int> _decodePcm16(Uint8List bytes) {
    final data = ByteData.sublistView(bytes);
    final length = bytes.length ~/ 2;
    final samples = List<int>.filled(length, 0, growable: false);

    for (int i = 0; i < length; i++) {
      samples[i] = data.getInt16(i * 2, Endian.little);
    }

    return samples;
  }

  Future<void> _handleAudioChunk(Uint8List bytes) async {
    try {
      final samples = _decodePcm16(bytes);
      if (samples.isEmpty) return;

      final normalized = <double>[];
      for (final sample in samples) {
        final value = sample / 32768.0;
        normalized.add(value);
        _waveformBuffer.add(value);

        if (_waveformBuffer.length > _targetInputSamples) {
          _waveformBuffer.removeFirst();
        }
      }

      final currentDb = _estimateDb(samples);
      final smoothedDb = _pushDbAndGetAverage(currentDb);

      bool inferenceRan = false;

      if (_waveformBuffer.length >= _targetInputSamples) {
        final now = DateTime.now();

        if (_lastInferenceAt == null ||
            now.difference(_lastInferenceAt!).inMilliseconds >=
                _inferenceIntervalMs) {
          _lastInferenceAt = now;

          final inferenceResult = _runInference(
            _waveformBuffer.toList(growable: false),
          );

          if (inferenceResult != null) {
            _lastLabel = inferenceResult.label;
            _lastRawLabel = inferenceResult.rawLabel;
            _lastScene = inferenceResult.scene;
            _lastConfidence = inferenceResult.confidence;
            _lastRawConfidence = inferenceResult.rawConfidence;
            _lastIsStable = inferenceResult.isStable;
            _lastTopPredictions = inferenceResult.topPredictions;
            _lastInferenceTimeMs = inferenceResult.inferenceTimeMs;
            inferenceRan = true;
          }
        }
      }

      final now = DateTime.now();
      final shouldEmit =
          inferenceRan ||
          _lastUiEmitAt == null ||
          now.difference(_lastUiEmitAt!).inMilliseconds >= _uiEmitIntervalMs;

      if (!shouldEmit) return;
      _lastUiEmitAt = now;

      if (_controller != null && !_controller!.isClosed) {
        _controller!.add(
          SoundClassificationResult(
            label: _lastLabel,
            rawLabel: _lastRawLabel,
            scene: _lastScene,
            confidence: _lastConfidence,
            rawConfidence: _lastRawConfidence,
            isStable: _lastIsStable,
            topPredictions: _lastTopPredictions,
            inferenceTimeMs: _lastInferenceTimeMs,
            currentDb: currentDb,
            smoothedDb: smoothedDb,
          ),
        );
      }
    } catch (error, stackTrace) {
      if (_controller != null && !_controller!.isClosed) {
        _controller!.addError(error, stackTrace);
      }
    }
  }

  double _estimateDb(List<int> samples) {
    if (samples.isEmpty) return 0.0;

    double sumAbs = 0.0;
    int peak = 0;

    for (final sample in samples) {
      final absValue = sample.abs();
      sumAbs += absValue;
      if (absValue > peak) peak = absValue;
    }

    final avgAbs = sumAbs / samples.length;
    final avgNorm = avgAbs / 32768.0;
    final peakNorm = peak / 32768.0;

    final blended = (avgNorm * 0.8) + (peakNorm * 0.2);
    double db = blended * 950.0;

    if (db < 8.0) return 0.0;
    if (db.isNaN || db.isInfinite) return 0.0;

    return db.clamp(0.0, 120.0).toDouble();
  }

  double _pushDbAndGetAverage(double value) {
    _dbWindow.addLast(value);

    while (_dbWindow.length > 8) {
      _dbWindow.removeFirst();
    }

    double total = 0.0;
    for (final item in _dbWindow) {
      total += item;
    }

    _lastSmoothedDb = total / _dbWindow.length;
    return _lastSmoothedDb;
  }

  SoundClassificationResult? _runInference(List<double> waveform) {
    final interpreter = _interpreter;
    if (interpreter == null) return null;

    final inputTensor = interpreter.getInputTensor(0);
    final inputShape = inputTensor.shape;
    final Object input = inputShape.length == 1 ? waveform : [waveform];

    final outputTensors = interpreter.getOutputTensors();
    final outputs = <int, Object>{};

    for (int i = 0; i < outputTensors.length; i++) {
      outputs[i] = _createFilledOutput(outputTensors[i].shape);
    }

    interpreter.runForMultipleInputs([input], outputs);

    final firstOutput = outputs[0];
    if (firstOutput == null) return null;

    final rawScores = _flattenToDoubleList(firstOutput);
    if (rawScores.isEmpty) return null;

    final scores = _collapseScores(rawScores, _labels.length);
    if (scores.isEmpty) return null;

    final scoreMap = _buildScoreMap(scores, _labels);
    if (scoreMap.isEmpty) {
      return SoundClassificationResult(
        label: 'Ambient / Unknown',
        rawLabel: 'Unknown',
        scene: 'Unknown',
        confidence: 0.0,
        rawConfidence: 0.0,
        isStable: false,
        topPredictions: const [],
        inferenceTimeMs:
            interpreter.lastNativeInferenceDurationMicroSeconds ~/ 1000,
        currentDb: 0.0,
        smoothedDb: _lastSmoothedDb,
      );
    }

    final smoothed = _smoother.addFrame(scoreMap);

    return SoundClassificationResult(
      label: smoothed.label,
      rawLabel: smoothed.rawLabel,
      scene: _mapLabelToScene(smoothed.label),
      confidence: smoothed.confidence.clamp(0.0, 1.0).toDouble(),
      rawConfidence: smoothed.rawConfidence.clamp(0.0, 1.0).toDouble(),
      isStable: smoothed.isStable,
      topPredictions: smoothed.topPredictions,
      inferenceTimeMs:
          interpreter.lastNativeInferenceDurationMicroSeconds ~/ 1000,
      currentDb: 0.0,
      smoothedDb: _lastSmoothedDb,
    );
  }

  Map<String, double> _buildScoreMap(List<double> scores, List<String> labels) {
    final map = <String, double>{};
    final length = scores.length < labels.length
        ? scores.length
        : labels.length;

    for (int i = 0; i < length; i++) {
      final score = scores[i].clamp(0.0, 1.0).toDouble();
      if (score < 0.08) continue;
      map[labels[i]] = score;
    }

    return map;
  }

  Object _createFilledOutput(List<int> shape) {
    if (shape.isEmpty) return 0.0;
    return _createFilledOutputRecursive(shape, 0);
  }

  Object _createFilledOutputRecursive(List<int> shape, int index) {
    final size = shape[index];
    final isLeaf = index == shape.length - 1;

    if (isLeaf) {
      return List<double>.filled(size, 0.0);
    }

    return List.generate(
      size,
      (_) => _createFilledOutputRecursive(shape, index + 1),
      growable: false,
    );
  }

  List<double> _flattenToDoubleList(Object value) {
    if (value is List) {
      final result = <double>[];
      for (final item in value) {
        result.addAll(_flattenToDoubleList(item as Object));
      }
      return result;
    }

    if (value is num) return [value.toDouble()];
    return const [];
  }

  List<double> _collapseScores(List<double> values, int classCount) {
    if (classCount <= 0) return const [];
    if (values.length == classCount) return values;

    if (values.length % classCount != 0) {
      return values.take(classCount).toList();
    }

    final frameCount = values.length ~/ classCount;
    final averaged = List<double>.filled(classCount, 0.0);

    for (int frame = 0; frame < frameCount; frame++) {
      for (int cls = 0; cls < classCount; cls++) {
        averaged[cls] += values[(frame * classCount) + cls];
      }
    }

    for (int i = 0; i < averaged.length; i++) {
      averaged[i] /= frameCount;
    }

    return averaged;
  }

  String _mapLabelToScene(String label) {
    final value = label.toLowerCase();

    if (_matchesAny(value, const [
      'speech',
      'conversation',
      'narration',
      'whisper',
      'shout',
      'yell',
      'laughter',
      'babbling',
      'humming',
    ])) {
      return 'Conversation';
    }

    if (_matchesAny(value, const [
      'crowd',
      'cheering',
      'applause',
      'chatter',
      'hubbub',
      'children playing',
      'inside, public space',
    ])) {
      return 'Crowd';
    }

    if (_matchesAny(value, const [
      'music',
      'singing',
      'guitar',
      'piano',
      'drum',
      'orchestra',
      'choir',
      'electronic music',
      'rock music',
      'jazz',
      'song',
      'background music',
    ])) {
      return 'Music / Event';
    }

    if (_matchesAny(value, const [
      'traffic',
      'vehicle',
      'car',
      'bus',
      'truck',
      'motorcycle',
      'train',
      'subway',
      'metro',
      'aircraft',
      'airplane',
      'helicopter',
      'horn',
      'siren',
      'roadway',
    ])) {
      return 'Traffic';
    }

    if (_matchesAny(value, const [
      'engine',
      'drill',
      'jackhammer',
      'power tool',
      'chainsaw',
      'lawn mower',
      'vacuum cleaner',
      'blender',
      'hair dryer',
      'printer',
      'mechanical fan',
      'air conditioning',
      'hammer',
      'sawing',
      'alarm',
      'buzzer',
    ])) {
      return 'Machinery';
    }

    if (_matchesAny(value, const [
      'silence',
      'inside, small room',
      'inside, large room or hall',
      'typing',
      'computer keyboard',
      'writing',
      'tick',
      'tick-tock',
      'white noise',
      'pink noise',
      'ambient / unknown',
    ])) {
      return 'Quiet Indoor';
    }

    return 'Unknown';
  }

  bool _matchesAny(String value, List<String> patterns) {
    for (final pattern in patterns) {
      if (value.contains(pattern)) return true;
    }
    return false;
  }

  Future<void> stop() async {
    await _audioSubscription?.cancel();
    _audioSubscription = null;

    try {
      await _recorder.stop();
    } catch (_) {}

    _waveformBuffer.clear();
    _dbWindow.clear();
    _lastInferenceAt = null;
    _lastUiEmitAt = null;
    _lastSmoothedDb = 0.0;
    _smoother.reset();
    _resetLastAiState();

    await _controller?.close();
    _controller = null;
  }

  Future<void> dispose() async {
    await stop();
    await _recorder.dispose();
    _interpreter?.close();
    _interpreter = null;
    _isInitialized = false;
  }
}
